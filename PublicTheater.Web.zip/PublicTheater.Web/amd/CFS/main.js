﻿define([

    'cfs'

], function (CFS) {

    window.cfs = new CFS.App();

});