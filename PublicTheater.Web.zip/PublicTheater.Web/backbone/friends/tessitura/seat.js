﻿

define([

    'friends/base/model'

], function (BaseModel) {

    return BaseModel.extend({

    });

});