﻿

define([

    'base/view'

], function (BaseView) {

    return BaseView.extend({
        // There are no base properties. This is just an example.

        //selector: "[data-bb-control]",

        //events: {
        //    "click [data-bb-control]": "didClickControl"
        //},

        //initialize: function () {

        //},

        //didRender: function () {

        //}
    });

});