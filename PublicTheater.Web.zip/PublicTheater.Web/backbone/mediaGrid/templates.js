﻿define(['handlebars'], function(Handlebars) {

this["JST"] = this["JST"] || {};

this["JST"]["watchAndListen"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "";


  return buffer;
  });

return this["JST"];

});