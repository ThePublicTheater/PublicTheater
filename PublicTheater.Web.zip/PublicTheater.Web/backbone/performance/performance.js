﻿define([

    'base/model'

], function (BaseModel) {

    return BaseModel.extend({

    });

});