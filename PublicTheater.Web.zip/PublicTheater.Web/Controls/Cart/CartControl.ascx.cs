﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PublicTheater.Web.Controls.Cart
{
    public class CartControl : TheaterTemplate.Web.Controls.CartControls.CartControl
    {
        protected override void BindContentPieces()
        {
            base.BindContentPieces();
        }
    }
}