﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using TheaterTemplate.Shared.GiftCertificateObjects;

namespace PublicTheater.Web.Controls.Gift
{
    public class GiftCertificateImageService : TheaterTemplate.Web.Controls.GiftControls.GiftCertificateImageService
    {
       
    }
}