﻿module.exports = {

//    'path/to/templates.js': [
//        'path/to/*.handlebars'
    //    ]
    
};