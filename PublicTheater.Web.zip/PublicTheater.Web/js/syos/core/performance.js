﻿(function ($) {
	SYOSPerformance = Backbone.Model.extend({
		initialize : function () {
			
		}
	});
})(jQuery);