﻿
//$(document).ready(function () {
//    $(".subHeader").hide();
//});

//HIDE SUB NAV ON WATCH AND LISTEN
$(document).ready(function () {
    $(".WnL").parent().closest('div').find('#leftNav1_subNavPanel').find('.subHeader.top-bar').hide();
});