PassKit CSharp API Wrapper uses:

- RestSharp v104.1.0.0 (http://restsharp.org/)
 
PassKit CSharp API Wrapper - Supported methods

Template methods:
- List templates;
- Get passes for template;
- Update template;
- ** NEW ** Reset template;

Pass methods:
- Issue pass;
- Get pass details (via pass-id);
- Get pass details (via template & serial);
- Update pass (via pass-id);
- Update pass (via template & serial);

Image methods:
- ** NEW ** Upload image;
- ** NEW ** Get image data;
