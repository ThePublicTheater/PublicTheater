# Set this to the root of your project when deployed:
http_path = "/"
css_dir = "Static/stylesheets"
sass_dir = "Static/sass"
images_dir = "Static/img"
javascripts_dir = "Static/js"
fonts_dir = "Static/fonts"
debug_info = false
output_style = :compact
line_comments = false
sass_options = { :debug_info => false }



