﻿

define([

    'backbone'

], function (Backbone) {

    return Backbone.Model.extend({

        defaults: {
            error: false
        }

    });

});