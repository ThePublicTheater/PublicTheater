﻿define([

    'jquery',
    'custom'

], function ($) {

    $(document).ready(function () {
        //initRotator($('.slideshow'), 'fade');
    });

});
